import mongoose from 'mongoose';

const costumerSchema=new mongoose.Schema({
    name:String,
    email:String,
    password:String
})
const User = new mongoose.model("User",costumerSchema)

export default User;