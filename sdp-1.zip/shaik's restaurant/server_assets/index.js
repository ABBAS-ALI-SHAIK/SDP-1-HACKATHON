import express from 'express';
import bodyParser from 'body-parser';
import mongoose from 'mongoose';
import cors from 'cors';
import User from './models/user.js'

const app=express();


app.use(bodyParser.json({ limit: "30mb", extended: true}));
app.use(bodyParser.urlencoded({ limit: "30mb", extended: true}));
app.use(cors());

const CONNECTION_URL="mongodb+srv://2000030016:2000030016@cluster0.nbyn7.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";
const PORT= process.env.PORT || 5000;

mongoose.connect(CONNECTION_URL,{useNewUrlParser:true,useUnifiedTopology:true})
    .then(()=> app.listen(PORT, ()=>console.log(`Server running on port: ${PORT}`)))
    .catch((error) =>console.log(error.message));



//Routes
app.post("/login",(req,res)=>{
    const {email, password}=req.body
    User.findOne({email:email},(err ,user)=>{
        if(user){
            if(password===user.password){
                res.send({message:"Login Successfull",user: user})
            } else {
                res.send({message: "Incorrect password! Check password and try again"})
            }
        }
        else{
            res.send({message: "User not registered"})
        }
    })
})

app.post("/register",(req,res)=>{
    const {name,email,password}=req.body
    User.findOne({email:email},(err,user)=>{
        if(user){
            res.send({message:"user already registered"})
        }
        else{
            const user =new User({
                name,email,password
            })
            user.save(err =>{
                if(err){
                    res.send(err)
                }
                else{
                    res.send({message:"Successfully Registered,Please Login"})
                }
            })
        }
    })
})