export function round(num) {
    return Math.round(num * 100) / 100
};