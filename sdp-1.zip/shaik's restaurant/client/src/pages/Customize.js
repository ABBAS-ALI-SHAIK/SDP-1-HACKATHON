import React from "react";
import DeliveryMenu from '../components/CustomizeMenu'
import CustomParallax from '../components/CustomParallax'
import home_top from "../assets/home_top.jpg";


export default function Delivery() {
    return (
        <React.Fragment>
            <CustomParallax title='design your own' img={home_top} height={300}/>
            <DeliveryMenu className='Delivery'/>
        </React.Fragment>
    );
}