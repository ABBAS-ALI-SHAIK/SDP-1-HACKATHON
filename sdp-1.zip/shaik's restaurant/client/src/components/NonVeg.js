import React from 'react';
import CustomParallax from '../components/CustomParallax'
import home_top from "../assets/home_top.jpg";
import NonVegMenu from './NonVegMenu';

export default function NonVeg() {
    return (
        <React.Fragment>
            <CustomParallax title='Non-Veg' img={home_top} height={300} />
            <NonVegMenu className='NonVeg'/>
        </React.Fragment>
    );
}