import React from 'react';
import {Col, Container, Row} from "react-bootstrap";

export default function CustomContainer() {
    return (
        <Container className='h-auto my-4 pt-3'>
            <Row className='h-100'>
                <Col className="text-center m-auto">
                    <h2 className='text-uppercase'>ABOUT US</h2>
                    <p className='m-auto w-75 pb-lg-5'>We exist to connect local Bostonians to each other through great tasting food and ciusines while also 
                    supporting local farmers and utilizing the freshest ingredients.We Serve only the highest quality product, prepare it in a clean and sparkling environment,
                     and serve it in a warm and friendly manner.
                    </p>
                </Col>
            </Row>
        </Container>
    );
}