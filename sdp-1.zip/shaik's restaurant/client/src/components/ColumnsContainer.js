import React from 'react';
import {Col, Container, Row} from "react-bootstrap";

export default function ColumnsContainer() {
    return (
        <Container className='mt-4'>
            <Row className='text-center'>
                <Col>
                    <h2>A DESTINATION</h2>
                </Col>
            </Row>
            <Row className='mt-3 text-left h-auto mb-4'>
                <Col className='mx-auto' md={5}>
                    <p>A restaurant (diner) is a place where cooked food is sold to the public, and where
                         people sit down to eat it. It is also a place where people go to enjoy the time and to eat a meal.
Some restaurants are a chain, meaning that there are restaurants which have the same name and serve the same food. McDonald's,
 Burger King, and Pizza Hut are examples of chain restaurants that are all over the world. These restaurants serve fast food, that is,
  inexpensive food, prepared and served quickly. At some, you do not have to even get out of the car to eat. You can pay and get your 
  order from a window.You can order food in online .
                    </p>
                </Col>

                <Col className='mx-auto' md={5}>
                    <p>Food ordering online is becoming a norm for restaurants which offer takeout and delivery orders. Food ordering
                         online is designed as it is cost effective yet an efficient system to satisfy the restaurants needs. The system 
                         is also designed for its ultimate flexibility and performance. The customers will be able to access into the company
                          existing website and browse at their menu and select and place their orders on what they desire. Once they have
                           completed their order, the system will either email or fax the customer’s order to the restaurant.And we can customize 
                           our orders with our own reciepie's.
                    </p>
                </Col>
            </Row>
        </Container>
    );
}