import React from 'react';
import {Col, Container, Row} from "react-bootstrap";

export default function KitchenNames() {
    return (
        <Container className='text-left text-dark text-uppercase'>
            <Row className='mt-3 h-auto'>
                <Col>
                    <h2>SHAIK SHAFEULLAH</h2>
                    <h5 className='text-secondary'>EXECUTIVE CHEF</h5>
                    <p className='text-lowercase'>As an executive chef Iam responsible for all of the food coming out of the kitchen.
                     Iam responsible for ensuring that the food comes out of the kitchen in a timely manner. A few of the main
                      duties of an executive chef is monitoring the quality of the food, following all food safety regulations,
                       creating new food entrees, and coordinating the entire kitchen. We also have to hire and train new kitchen 
                       staff. 
                    </p>
                </Col>

                <Col>
                    <h2>ABBAS ALI
                    </h2>
                    <h5 className='text-secondary'>CHEF DE CUISINE </h5>
                    <p className='text-lowercase'>There are no divisions in my kitchen or my restaurant. We always say, 
                    ‘The guest is an incarnation of God.’ I want people to feel that they are valued. They will be looked after
                     as if they’ve gone to a relative’s house. I’m cooking food from my home, from meals I’ve had in my family.
                      I tell them the stories of the dishes. I’m taking their hand, and taking them along. My aim is for you to leave
                       feeling like someone had embraced you. That’s how food should be. I get happiness from seeing people’s eyes when
                        they eat the food I’ve cooked. 
                    </p>
                </Col>

                <Col>
                    <h2>CHAITANYA </h2>
                    <h5 className='text-secondary'>PASTRY CHEF </h5>
                    <p className='text-lowercase'>To become a doctor, you need to go to medical school. To become a lawyer,
                     you need a J.D. But to become a chef, you just put your time in at restaurants and learn by doing</p>
                </Col>
            </Row>
        </Container>
    );
}