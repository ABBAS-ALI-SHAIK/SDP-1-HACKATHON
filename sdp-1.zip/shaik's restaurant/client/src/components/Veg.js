import React from 'react';
import CustomParallax from '../components/CustomParallax'
import home_top from "../assets/home_top.jpg";
import VegMenu from './VegMenu';

export default function NonVeg() {
    return (
        <React.Fragment>
            <CustomParallax title='Veg' img={home_top} height={300} />
            <VegMenu className='Veg'/>
        </React.Fragment>
    );
}