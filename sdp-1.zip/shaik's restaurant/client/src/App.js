import React, { useState} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import {BrowserRouter as Router, Switch, Route} from 'react-router-dom'
import {Header, Home, Delivery, Error, Gallery, MenuLunch, MenuEvening, Cart, Login, Signup, Customize, Checkout} from './utils'
import Footer from "./components/Footer";
import './App.css';
import NonVeg from './components/NonVeg';
import Veg from './components/Veg';

function App () {
    const [ loginUser, setLoginUser] = useState({ })
    return (
        <Router>
            <div className="App">
                <Header className="Header"/>
                <Switch>
                    <Route exact path="/">{loginUser && loginUser._id ? <Home setLoginUser={setLoginUser} /> : <Login setLoginUser={setLoginUser}/>}</Route>
                    <Route exact path="/home" component={Home}/>
                    <Route exact path="/delivery" component={Delivery}/>
                    <Route exact path="/gallery" component={Gallery}/>
                    <Route exact path="/menu.lunch" component={MenuLunch}/>
                    <Route exact path="/menu.evening" component={MenuEvening}/>
                    <Route exact path="/customize" component={Customize}/>
                    <Route exact path="/nonVeg" component={NonVeg}/>
                    <Route exact path="/veg" component={Veg}/>
                    <Route exact path="/cart" component={Cart}/>
                    <Route exact path="/login"><Login setLoginuser={setLoginUser}/></Route>
                    <Route exact path="/signup" component={Signup}/>
                    <Route exact path="/checkout" component={Checkout}/>
                    
                    <Route exact path="/" component={Login}/>
                    <Route component={Error}/>
                </Switch>
                <Footer/>
            </div>
        </Router>
    );
}



export default App;